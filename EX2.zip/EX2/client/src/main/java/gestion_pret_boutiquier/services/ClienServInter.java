package gestion_pret_boutiquier.services;
import gestion_pret_boutiquier.Core.Service;
import gestion_pret_boutiquier.Data.Entity.Client;

public interface ClienServInter extends Service<Client> {

    
}