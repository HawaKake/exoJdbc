package gestion_pret_boutiquier.Core.factory;

public class CompteServFacto {
    
}
