package gestion_pret_boutiquier.Data.Repository.List;

import java.util.ArrayList;
import java.util.List;

import gestion_pret_boutiquier.Data.Entity.Compte;

public class CompteRepoList extends RepoList<Compte> {
    
   
    
}
